# Author chaowga
# 2016.01.27
# get play by play live text from CBS Sports

import urllib2
from bs4 import BeautifulSoup
import os
import Queue

i_headers = {"User-Agent": "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1) Gecko/20090624 Firefox/3.5",
             "Accept": "text/plain"}

def save_game(a_list):
    for a in a_list:
        for a_child in a:
            try:
                if(a['class'][0] == 'gameTracker'):
                    live_link = 'http://www.cbssports.com' + a['href']
                    string_tokens = live_link.split('/')
                    if(string_tokens[5] == 'live'):
                        save_name = string_tokens[-1]
                        if(os.path.isfile('./files/text_live_file/'+save_name+'.html')):
                            continue
                        playbyplay_link = live_link.replace('live','playbyplay')
                        print save_name + "..."
                        playbyplay_response = urllib2.urlopen(playbyplay_link)
                        playbyplay_html = playbyplay_response.read()
                        print save_name
                        playbyplay_file = open('./files/text_live_file/'+save_name+'.html','w')
                        playbyplay_file.write(playbyplay_html)
                        playbyplay_file.close()
            except:
                continue

def deal_with_soup(a_html):
    soup = BeautifulSoup(a_html)
    a_html = soup.html
    a_list = a_html.find_all('a')
    save_game(a_list)

def get_tds(a_html):
    start = 0
    tds = ""
    while(a_html.find(u'<td', start) != -1):
        begin = a_html.find(u'<td', start)
        end = a_html.find(u'/td>', start)
        start = end+4
        tds += a_html[begin:start]
    return tds

myqueue = Queue.Queue(maxsize = 100)
prefix = 'http://www.cbssports.com/nba/scoreboard/2004'
for month in xrange(13):
     print month
     for day in xrange(32):
        print day
        if(0<month and month<10):
            if(0<day and day<10):
                req = urllib2.Request(prefix+'0'+str(month)+'0'+str(day), headers=i_headers)
            elif(10<=day):
                req = urllib2.Request(prefix+'0'+str(month)+str(day), headers=i_headers)
            else:
                continue
        elif(10<=month):
            if(0<day and day<10):
                req = urllib2.Request(prefix+str(month)+'0'+str(day), headers=i_headers)
            elif(10<=day):
                req = urllib2.Request(prefix+str(month)+str(day), headers=i_headers)
            else:
                continue
        else:
            continue
        try:
            response = urllib2.urlopen(req,None,5)
            html = response.read()
            html = u"<html>" + get_tds(html) + u"</html>"
            file_name = './files/days/' + str(month)+str(day) + '.html'
            deal_with_soup(html)
        except:
            print 'failed'
            failed_req = req
            myqueue.put(failed_req)
            continue

while(not myqueue.empty()):
    req = myqueue.get()
    try:
        response = urllib2.urlopen(req)
        html = response.read()
        html = u"<html>" + get_tds(html) + u"</html>"
        file_name = './files/days/' + str(month)+str(day) + '.html'
        deal_with_soup(html)
    except:
        print 'failed'
        failed_req = req
        myqueue.put(failed_req)
        continue
