# Author chaowga
# 2016.01.29
# Get every game play by play

import urllib
import urllib2
import json
import os
import socket

pbp_resultdir = '../files/play_by_play_json/'
gamebox_resultdir = '../files/gamebox/'
pbp_url = 'http://stats.nba.com/stats/playbyplayv2?'
gamebox_url = 'http://stats.nba.com/stats/boxscoretraditionalv2?'
i_headers = {
    u'Host':'stats.nba.com',
    u'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:41.0) Gecko/20100101 Firefox/41.0',
    u'Accept':'application/json, text/plain, */*',
    u'Accept-Language':'zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3',
    u'Referer':'http://stats.nba.com/game/',
    u'Cookie':'pgv_info=ssid=s9484447818; pgv_pvid=4743245339; AMCV_248F210755B762187F000101%40AdobeOrg=793872103%7CMCAAMB-1453732170%7CNRX38WO0n5BH8Th-nqAG_A%7CMCAAMLH-1453732170%7C11%7CMCIDTS%7C16819%7CMCMID%7C25911254955460191508610242740083291203; _ga=GA1.2.373318409.1453127370; s_ppvl=%5B%5BB%5D%5D; s_ppv=cn%253Amain%2C12%2C100%2C1112%2C1%2C1%2C1440%2C900%2C1%2CPL; s_cc=true; crtg_trnr=; ug=56a9fd6d0c829a0a3c8ef145b200a62a; s_fid=06D69A60AD8DC3EB-0AB8F348AF8B8C98; s_sq=%5B%5BB%5D%5D; __gads=ID=ad86e61cc300d3a2:T=1453981038:S=ALNI_MZPPlIifkVhMg2fnt3IDUVefDmaUQ; s_vi=[CS]v1|2B54FEB885013325-40000132A00121AE[CE]; ugs=1; _gat=1',
    u'Connection':'keep-alive'
}

i_paras = {
    u'EndPeriod':'10',
    u'EndRange':u'28800',
    u'GameID':u'',
    u'RangeType':u'0',
    u'Season':u'',
    u'SeasonType':u'Regular+Season',
    u'StartPeriod':'1',
    u'StartRange':'0'
}

req = urllib2.Request('http://stats.nba.com/stats/commonallplayers?IsOnlyCurrentSeason=0&LeagueID=00&Season=2015-16')
response = urllib2.urlopen(req,None,30)
results = response.read()
result_file = open('../files/commonPlay.json','w')
result_file.write(results)
result_file.close()

year = '1996'

def get_season(str_season):
    season_tail = (int(str_season)+1)%100
    if(season_tail == 0):
        return str_season+'-00'
    elif(season_tail < 10):
        return str_season+'-0'+str(season_tail)
    else:
        return str_season+'0'+str(season_tail)

def get_game_box(filename):
    day_json = json.loads(open(filename).read())
    result_sets = day_json[u'resultSets']
    for a_obj in result_sets:
        try:
            a_header = a_obj[u'headers']
            try:
                if(a_header[2] == u'GAME_ID'):
                    row_set = a_obj[u'rowSet']
                    for a_row in row_set:
                        tobe_saved = str(a_row[5])
                        parts = tobe_saved.split('/')
                        tobe_saved = gamebox_resultdir+parts[0]+'_'+parts[1]+'.json'
                        if(os.path.isfile(tobe_saved)):
                            continue
                        print a_row[5]
                        game_id = a_row[2]
                        i_paras[u'GameID'] = game_id
                        i_paras[u'Season'] = get_season(a_row[8])
                        data = urllib.urlencode(i_paras)
                        req = urllib2.Request(gamebox_url,data,i_headers)
                        response = urllib2.urlopen(req,None,30)
                        results = response.read()
                        result_file = open(tobe_saved,'w')
                        result_file.write(results)
                        result_file.close()
                    return
            except socket.timeout:
                print "failed"
                continue
            except:
                print 'not exist'
                continue
        except:
            continue

def get_game_pbp(filename):
    day_json = json.loads(open(filename).read())
    result_sets = day_json[u'resultSets']
    for a_obj in result_sets:
        try:
            a_header = a_obj[u'headers']
            try:
                if(a_header[2] == u'GAME_ID'):
                    row_set = a_obj[u'rowSet']
                    for a_row in row_set:
                        tobe_saved = str(a_row[5])
                        parts = tobe_saved.split('/')
                        tobe_saved = pbp_resultdir+parts[0]+'_'+parts[1]+'.json'
                        if(os.path.isfile(tobe_saved)):
                            continue
                        print a_row[5]
                        game_id = a_row[2]
                        i_paras[u'GameID'] = game_id
                        i_paras[u'Season'] = get_season(a_row[8])
                        data = urllib.urlencode(i_paras)
                        req = urllib2.Request(pbp_url,data,i_headers)
                        response = urllib2.urlopen(req,None,30)
                        results = response.read()
                        result_file = open(tobe_saved,'w')
                        result_file.write(results)
                        result_file.close()
                    return
            except socket.timeout:
                print "failed"
                continue
            except:
                print 'not exist'
                continue
        except:
            continue

'2015/gameinfo/20160203/0021500735_Book.pdf'
gameBookPrefix = 'http://www.nba.com/data/html/nbacom/'
gameBookLocalFolder = '../files/GameBook/'
def get_game_book(filename):
    day_json = json.loads(open(filename).read())
    result_sets = day_json[u'resultSets']
    for a_obj in result_sets:
        try:
            a_header = a_obj[u'headers']
            try:
                if(a_header[2] == u'GAME_ID'):
                    row_set = a_obj[u'rowSet']
                    for a_row in row_set:
                        tobe_saved = str(a_row[5])
                        parts = tobe_saved.split('/')
                        tobe_saved = gameBookLocalFolder+parts[0]+'_'+parts[1]+'.pdf'
                        if(os.path.isfile(tobe_saved)):
                            continue
                        print a_row[5]
                        game_id = a_row[2]
                        bookUrl = gameBookPrefix+year+'/gameinfo/'+parts[0]+'/'+game_id+'_Book.pdf'
                        urllib.urlretrieve(bookUrl, tobe_saved)
                    return
            except socket.timeout:
                print "failed"
                continue
            except:
                print 'not exist'
                continue
        except:
            continue

rootdir = "../files/days/"
#get_game_pbp(rootdir+'20060409.json')

for parent, dirnames, filenames in os.walk(rootdir):
    for filename in filenames:
        if(not filename.startswith(year)):
            continue
        try:
            print filename
            #get_game_pbp(rootdir + filename)
            get_game_box(rootdir + filename)
            #get_game_book(rootdir + filename)
        except:
            continue