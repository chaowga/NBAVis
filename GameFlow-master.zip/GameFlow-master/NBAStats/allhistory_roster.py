import simplejson as json

jsonobject = json.load(file("../files/commonPlay.json"))
rowSet = jsonobject['resultSets'][0]['rowSet']
print rowSet

roster = open("../files/allhistory_rost.csv",'w')
for player in rowSet:
    newone = ''
    newone += player[2]
    newone += ','
    newone += player[4]
    newone += ','
    newone += player[5]
    newone += ','
    newone += player[12]
    newone += '\r\n'
    roster.write(newone)
roster.close()