# Author chaowga
# 2016.01.28
# get play by play live text from stats.nba.com

import urllib2
from bs4 import BeautifulSoup
import os
import Queue
import socket

# Save the response to file
def save_to_file(filename, content):
    playbyplay_file = open(filename,'w')
    playbyplay_file.write(content)
    playbyplay_file.close()

def save_failed_links(failed_queue, year):
    failed_file = open("../files/days/failed"+str(year)+".txt", "w")
    while(not failed_queue.empty()):
        failed_file.write(failed_queue.get())
        failed_file.write('\n')
    failed_file.close()

# Set up headers and links
i_headers = {
    "Host": "stats.nba.com",
    "User-Agent": "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.9.1) Gecko/20090624 Firefox/3.5",
    "Accept": "application/json, text/plain, */*",
    "Accept-Launguage": "zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3",
    #"Accept-Encoding": "gzip, deflate",
    "Referer": "http://stats.nba.com/scores/?ls=iref:nba:gnav",
    "Cookie": "pgv_info=ssid=s9484447818; pgv_pvid=4743245339; AMCV_248F210755B762187F000101%40AdobeOrg=793872103%7CMCAAMB-1453732170%7CNRX38WO0n5BH8Th-nqAG_A%7CMCAAMLH-1453732170%7C11%7CMCIDTS%7C16819%7CMCMID%7C25911254955460191508610242740083291203; _ga=GA1.2.373318409.1453127370; s_ppvl=%5B%5BB%5D%5D; s_ppv=cn%253Amain%2C12%2C100%2C1112%2C1%2C1%2C1440%2C900%2C1%2CPL; s_cc=true; crtg_trnr=; ug=56a9fd6d0c829a0a3c8ef145b200a62a; ugs=1; s_fid=06D69A60AD8DC3EB-0AB8F348AF8B8C98; s_sq=%5B%5BB%5D%5D; __gads=ID=ad86e61cc300d3a2:T=1453981038:S=ALNI_MZPPlIifkVhMg2fnt3IDUVefDmaUQ; s_vi=[CS]v1|2B54FEB885013325-40000132A00121AE[CE]; _gat=1",
    "Connection": "keep-alive"
}

failed_reqs = Queue.Queue(maxsize = 1000)
year = "1990"
prefix = "http://stats.nba.com/stats/scoreboardV2?DayOffset=0&LeagueID=00&gameDate="
for month in xrange(13):
    print month
    for day in xrange(32):
        print day
        if(0<month and month<10):
            if(0<day and day<10):
                link = prefix+'0'+str(month)+"/0"+str(day)+'/'+str(year)
                post_filename = str(str(year))+'0'+str(month)+'0'+str(day)
            elif(10<=day):
                link = prefix+'0'+str(month)+'/'+str(day)+'/'+str(year)
                post_filename = str(str(year))+'0'+str(month)+str(day)
            else:
                continue
        elif(10<=month):
            if(0<day and day<10):
                link = prefix+str(month)+"/0"+str(day)+'/'+str(year)
                post_filename = str(str(year))+str(month)+'0'+str(day)
            elif(10<=day):
                link = prefix+str(month)+'/'+str(day)+'/'+str(year)
                post_filename = str(year)+str(month)+str(day)
            else:
                continue
        else:
            continue
        req = urllib2.Request(link, headers=i_headers)
        try:
            save_filename = "../files/days/"+post_filename+".json"
            if(os.path.isfile(save_filename)):
                continue
            print save_filename + "..."
            response = urllib2.urlopen(req,None,30)
            results = response.read()
            save_to_file(save_filename, results)
            print save_filename
        except socket.timeout:
            print "failed"
            failed_reqs.put(link)
        except:
            continue
save_failed_links(failed_reqs, year)
