/* draw.js
   Draw the visualized play by play
   Author: chaowga
   Data: 2016.02.12
*/

var padding = { left:30, right:30, top:20, bottom:20 };
var secondTextHeight = 10;
var secondTextWidth = 0;
var lengthPerSecond = 12;
var lengthPerQuarter = lengthPerSecond * 60 * 12;
var quarterPadding = 300;
var lengthPerOT = lengthPerSecond * 60 * 5 + 300;
var width = 1200;
var height = 120000;
var middlePos= width/ 2;
var tieLineWidth= 4;

var svg = d3.select( "body" )
            .append( "svg" )
            .attr( "transform", "translate(" + padding.left + "," + padding.top + ")" )
            .attr( "width", width )
            .attr( "height", height );

var quarterScale = d3.scale.linear()
    .domain( [ 0, 60 * 12 ] )
    .range( [ lengthPerQuarter, 0 ] );

var OTScale = d3.scale.linear()
    .domain( [ 0, 60 * 5 ] )
    .range( [ lengthPerOT, 0 ] );

function convertToSecond( strTime ) {
    if( null == strTime )
        return 60 * 12;

    var tmpList = strTime.split( ':' );
    return 60 * parseInt( tmpList[0] ) + parseInt( tmpList[1] );
}

var preProcess = function( obj ) {
    var resultSets = obj.resultSets;
    var playByPlay = resultSets[0].rowSet;
    return playByPlay;
}

function ScoreComparator( visitor, host ) {
    this.visitor = visitor;
    this.host = host;
    this.diff = 0;

    this.compareScores = function( data ) {
        if( null == data ) {
            return this.diff;
        }

        var scores = data.toString().split( "-" );
        this.visitor = scores[0];
        this.host = scores[1];
        this.diff = 10 * ( parseInt( this.visitor ) - parseInt( this.host ) );

        return this.diff;
    }
}

var drawPart = function( data ) {
    var dataToDraw = preProcess( data );
    var quarter = 0;
    var scoreComparator = new ScoreComparator( 0, 0 );

    // draw tie line
    svg.selectAll(".TieLine")
        .data( dataToDraw )
        .enter()
        .append( "rect" )
        .attr( "transform", "translate(" + ( middlePos ) + "," + 0 + ")" )
        .attr( "class", "TieLine" )
        .attr( "x", 0 )
        .attr( "y", function( d, i ) {
            if( i == 0 ) {
                return 0;
            }
            if( "12:00" == d[6] && "12:00" != dataToDraw[i-1][6] )
                ++quarter;

            if( quarter < 5 )
                return ( lengthPerQuarter + quarterPadding ) * quarter + quarterScale( convertToSecond( dataToDraw[i-1][6] ) );
            else
                return ( lengthPerQuarter + quarterPadding ) * 4 + lengthPerOT * ( quarter - 4 ) + quarterScale( convertToSecond( dataToDraw[i-1][6] ) );
        } )
        .attr( "width", tieLineWidth )
        .attr( "height", function( d, i ) {
            if( i == 0 ) {
                return 0;
            }

            return ( quarterScale( convertToSecond( d[6] ) ) - quarterScale( convertToSecond( dataToDraw[i-1][6] ) ) );
        } );

    quarter = 0;
    // draw time
    svg.selectAll( "text" )
        .data( dataToDraw )
        .enter()
        .append( "text" )
        .attr( "class", "TimeText" )
        .attr( "transform", "translate(" + ( middlePos ) + "," + 0 + ")" )
        .attr( "x", 2 )
        .attr( "y", function( d, i ) {
            if( 0 == i )
                return 0;

            if( "12:00" == d[6] && "12:00" != dataToDraw[i-1][6] )
                ++quarter;

            if( quarter < 5)
                return ( lengthPerQuarter + quarterPadding ) * quarter + quarterScale( convertToSecond( d[6] ) );
            else
                return ( lengthPerQuarter + quarterPadding ) * 4 + ( quarter - 4 ) * lengthPerOT + quarterScale( convertToSecond( d[6] ) );
        } )
        .text( function( d, i ) {
            return d[6];
        } );

    // draw play by play
    quarter = 0;
    svg.selectAll( ".PlayByPlay")
        .data( dataToDraw )
        .enter()
        .append( "rect" )
        .attr( "class", "PlayByPlay")
        .attr( "transform", "translate(" + 0 + "," + 0 + ")" )
        .attr( "x", function( d, i ) {
            return 0;
        })
        .attr( "y", function( d, i ) {
            if( 0 == i )
                return 0;

            if( "12:00" == d[6] && "12:00" != dataToDraw[i-1][6] )
                ++quarter;

            if( quarter < 5 )
                return ( lengthPerQuarter + quarterPadding ) * quarter + quarterScale( convertToSecond( d[6]) );
            else
                return ( lengthPerQuarter + quarterPadding ) * 4 + ( quarter - 4 ) * lengthPerOT + quarterScale( convertToSecond( d[6]) );
        } )
        .attr( "width", function( d, i ) {
            return width / 2 + scoreComparator.compareScores( d[10] );
        } )
        .attr( "height", function( d, i ) {
            if( 0 == i ) {
                return 0;
            } else if( "0:00" == d[6] ) {
                return 100;
            }

            return ( quarterScale( convertToSecond( dataToDraw[i+1][6] ) ) - quarterScale( convertToSecond( d[6] ) ) );
        } );
}

d3.json( "../files/play_by_play_json/20110410_DETCHA.json", function( data ) {
    drawPart( data );
} );
